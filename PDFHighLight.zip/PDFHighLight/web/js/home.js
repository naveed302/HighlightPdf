/**
 *Naveed Khan
 * 
 */

function showPdf(){
var docPath="http://localhost:8187/PDFHighLight/INVOICEperiod1-4.pdf";
var pageNo="#page=5";
var zoom="&zoom=150,0,"
var yCoordinate="516.31274";

//http://localhost:8187/PDFHighLight/INVOICEperiod1-4.pdf#page=5&zoom=75,0,516.31274
var finalPath=docPath+pageNo+zoom+yCoordinate;
var docFrame= "<iframe title='sample' name='processDocView' id='processDocView' width='100%' height='100%' src='js/pdfjs/web/viewer.html?file="+finalPath+"frameborder='0'></iframe>";


$( "#processDoc" ).append(docFrame);
}